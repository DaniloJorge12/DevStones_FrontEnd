import { useEffect, useState } from 'react';
import './LivroPrincipal.css';

import MenuLateral from '../../components/Drawer/MenuLateral.jsx';
import Cabecalho from '../../components/Layout/Cabecalho.jsx';
import Rodape from '../../components/Layout/Rodape.jsx';
import CartaoPersonagem from '../../components/LivroPrincipal/CartaoPersonagem.jsx';

const API_BASE = 'https://clubelivro-backend-zui4.onrender.com/api';
const API_KEY  = 'livr0';
const ID_LIVRO_CAMINHO_PEDRAS = 1;

export default function LivroPrincipal({ usuario, aoSair }) {
  const [livro, setLivro] = useState(null);
  const [erro, setErro] = useState(false);

  useEffect(() => {
    async function carregarLivro() {
      try {
        const headers = {
          'x-api-key': API_KEY,
          'Content-Type': 'application/json',
        };

        const [livroRes, personagensRes] = await Promise.all([
          fetch(`${API_BASE}/livro`, { method: 'GET', headers }),
          fetch(`${API_BASE}/personagem`, { method: 'GET', headers }),
        ]);

        if (!livroRes.ok || !personagensRes.ok) {
          throw new Error(`HTTP error: livro=${livroRes.status} personagens=${personagensRes.status}`);
        }

        const livrosAPI = await livroRes.json();
        const personagensAPI = await personagensRes.json();

        // Normaliza: aceita array ou objeto único
        const lista = Array.isArray(livrosAPI) ? livrosAPI : [livrosAPI];

        // Pega apenas "O Caminho das Pedras" pelo id
        const livroAPI = lista.find(
          (l) => Number(l.id) === ID_LIVRO_CAMINHO_PEDRAS
        ) ?? lista[0]; // fallback pro primeiro se não achar pelo id

        if (!livroAPI) throw new Error('Livro não encontrado na API');

        // Filtra personagens deste livro (tenta vários nomes de campo)
        const personagensLivro = Array.isArray(personagensAPI)
          ? personagensAPI
              .filter((p) => {
                const idRef =
                  p.idLivro ?? p.livroId ?? p.livro_id ?? p.id_livro;
                return Number(idRef) === Number(livroAPI.id);
              })
              .map((p) => ({
                nome: p.nome ?? 'Sem nome',
                descricao: p.descricao ?? 'Sem descrição',
              }))
          : [];

        setLivro({
          titulo: livroAPI.titulo ?? 'Sem título',
          autor: livroAPI.autor ?? 'Autor desconhecido',
          ano: livroAPI.anoPublicacao ?? '---',
          genero: livroAPI.genero ?? '',
          resumo: livroAPI.resumo ?? 'Sem resumo',
          analise: livroAPI.caracteristicasLiterarias ?? 'Sem análise',
          contexto: livroAPI.contexto ?? 'Sem contexto',
          personagens: personagensLivro,
          capa: livroAPI.capa ?? '',
        });
      } catch (e) {
        console.error('Erro ao carregar livro:', e);
        setErro(true);
      }
    }

    carregarLivro();
  }, []);

  if (erro) {
    return (
      <div className="paginaLivro">
        <MenuLateral itemAtivo="O Livro Principal" aoSair={aoSair} />
        <div className="conteudoLivro">
          <Cabecalho usuario={usuario} aoSair={aoSair} />
          <main className="areaLivro">
            <div className="erroContainer">
              <p>Erro ao carregar o livro. Verifique o console (F12).</p>
            </div>
          </main>
          <Rodape />
        </div>
      </div>
    );
  }

  if (!livro) {
    return (
      <div className="paginaLivro">
        <MenuLateral itemAtivo="O Livro Principal" aoSair={aoSair} />
        <div className="conteudoLivro">
          <Cabecalho usuario={usuario} aoSair={aoSair} />
          <main className="areaLivro">
            <div className="loadingContainer">
              <div className="loadingSpinner" />
              <p>Carregando...</p>
            </div>
          </main>
          <Rodape />
        </div>
      </div>
    );
  }

  return (
    <div className="paginaLivro">
      <MenuLateral itemAtivo="O Livro Principal" aoSair={aoSair} />

      <div className="conteudoLivro">
        <Cabecalho usuario={usuario} aoSair={aoSair} />

        <main className="areaLivro">
          <div className="conteudoLivro__inner">

          {/* ── HERO ── */}
          <section className="heroLivro">
            <div className="imagemLivro">
              <img
                src={livro.capa || 'https://placehold.co/300x450'}
                alt={livro.titulo}
                onError={(e) => { e.target.src = 'https://placehold.co/300x450'; }}
              />
            </div>

            <div className="infoLivro">
              <h1>{livro.titulo}</h1>

              <p className="subtituloLivro">
                &quot;Uma história de gente magra, de fome e de lutas invisíveis.&quot;
              </p>

              <p className="descricaoLivro">
                Publicado em {livro.ano}, {livro.autor} apresenta uma narrativa
                marcada por conflitos sociais, tensões políticas e a organização
                da classe trabalhadora no Brasil dos anos 30.
              </p>
            </div>
          </section>

          {/* ── CARDS RESUMO + ANÁLISE ── */}
          <section className="cardsLivro">
            <div className="cardLivro">
              <h3>Resumo da Obra</h3>
              <p>{livro.resumo}</p>
            </div>

            <div className="cardLivro">
              <h3>Análise Crítica</h3>
              <p>{livro.analise}</p>
            </div>
          </section>

          {/* ── PERSONAGENS ── */}
          <section className="personagens">
            <h2>Personagens Principais</h2>
            <p className="subtituloSecao">As peças fundamentais desta saga política e emocional</p>

            <div className="gridPersonagens">
              {livro.personagens.length === 0 ? (
                <p className="semPersonagens">Nenhum personagem encontrado.</p>
              ) : (
                livro.personagens.map((personagem, index) => (
                  <CartaoPersonagem
                    key={index}
                    nome={personagem.nome}
                    descricao={personagem.descricao}
                  />
                ))
              )}
            </div>
          </section>

          {/* ── CONTEXTO ── */}
          <section className="contextoLivro">
            <img
              src={livro.capa || 'https://placehold.co/300x450'}
              alt={livro.titulo}
              onError={(e) => { e.target.src = 'https://placehold.co/300x450'; }}
            />
            <div className="textoContexto">
              <h2>O Brasil de 1937</h2>
              <p>{livro.contexto}</p>
            </div>
          </section>

          </div>{/* fim conteudoLivro__inner */}
        </main>

        <Rodape />
      </div>
    </div>
  );
}